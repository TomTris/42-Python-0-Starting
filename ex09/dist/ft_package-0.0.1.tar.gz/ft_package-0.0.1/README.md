# My first Python library

Loading function
ft_tqdm - reproduce tqdm in my own style.